import React from 'react'
import '../styles/cardStyles.css'

const Card = ({ name, setSearchInput }: any) => {
    return (

        <div className='Card'>
            <button className='PokeImage' onClick={() => { setSearchInput(name) }}>
                <img className='PokeImage'
                    src={`https://projectpokemon.org/images/normal-sprite/${name}.gif`}
                />
            </button>

            <div>
                {name}
            </div>
        </div>

    )
}

export default Card



